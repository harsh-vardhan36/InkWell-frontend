import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { ThemeToggleComponent } from '../../../shared/components/theme-toggle/theme-toggle.component';
import { AuthSessionService } from '../../../features/auth/data-access/auth-session.service';

@Component({
  selector: 'app-public-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, ThemeToggleComponent],
  template: `
    <div class="public-shell">
      <header class="public-shell__header">
        <a class="public-shell__brand" routerLink="/">
          <span class="public-shell__mark">IW</span>
          <span>
            <strong>InkWell</strong>
            <small>Ideas worth rereading</small>
          </span>
        </a>

        <nav class="public-shell__nav" aria-label="Primary">
          <a routerLink="/" routerLinkActive="is-active" [routerLinkActiveOptions]="{ exact: true }">
            Home
          </a>
          <a routerLink="/feed" routerLinkActive="is-active">Feed</a>
          <a routerLink="/pricing" routerLinkActive="is-active">Pricing</a>
          <a *ngIf="canWrite()" routerLink="/write" routerLinkActive="is-active">Write</a>
        </nav>

        <div class="public-shell__actions">
          <app-theme-toggle />

          <ng-container *ngIf="isAuthenticated(); else guestActions">
            <a class="public-shell__ghost" routerLink="/profile">Profile</a>
            <a class="public-shell__cta" routerLink="/dashboard">Dashboard</a>
          </ng-container>

          <ng-template #guestActions>
            <a class="public-shell__ghost" routerLink="/login">Log in</a>
            <a class="public-shell__cta" routerLink="/register">Start writing</a>
          </ng-template>
        </div>
      </header>

      <main class="public-shell__main">
        <router-outlet />
      </main>
    </div>
  `,
  styles: [
    `
      .public-shell {
        min-height: 100vh;
      }

      .public-shell__header {
        position: sticky;
        top: 0;
        z-index: 10;
        display: grid;
        grid-template-columns: auto 1fr auto;
        gap: 1rem;
        align-items: center;
        padding: 1rem clamp(1rem, 3vw, 2rem);
        margin: 1rem clamp(1rem, 3vw, 2rem) 0;
        border: 1px solid var(--iw-border);
        border-radius: 1.4rem;
        background: color-mix(in srgb, var(--iw-surface) 88%, transparent);
        box-shadow: var(--iw-glass-shadow);
        backdrop-filter: blur(24px) saturate(155%);
      }

      .public-shell__brand {
        display: inline-flex;
        align-items: center;
        gap: 0.9rem;
        text-decoration: none;
      }

      .public-shell__mark {
        width: 2.75rem;
        height: 2.75rem;
        display: grid;
        place-items: center;
        border-radius: 0.9rem;
        background: linear-gradient(135deg, #8bb8ff 0%, #d8e8ff 100%);
        color: #123971;
        font-weight: 800;
        letter-spacing: 0.05em;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.55);
      }

      .public-shell__brand strong,
      .public-shell__brand small {
        display: block;
      }

      .public-shell__brand small {
        color: var(--iw-muted);
      }

      .public-shell__nav {
        display: inline-flex;
        justify-content: center;
        gap: 0.35rem;
        flex-wrap: wrap;
      }

      .public-shell__nav a,
      .public-shell__ghost,
      .public-shell__cta {
        padding: 0.75rem 1rem;
        border-radius: 999px;
        text-decoration: none;
        transition:
          background-color 180ms ease,
          color 180ms ease,
          transform 180ms ease;
      }

      .public-shell__nav a {
        color: var(--iw-muted);
      }

      .public-shell__nav a.is-active,
      .public-shell__nav a:hover {
        background: color-mix(in srgb, var(--iw-surface-solid) 72%, transparent);
        color: var(--iw-ink);
      }

      .public-shell__actions {
        display: inline-flex;
        align-items: center;
        gap: 0.75rem;
        flex-wrap: wrap;
        justify-content: flex-end;
      }

      .public-shell__ghost {
        border: 1px solid var(--iw-border);
        background: color-mix(in srgb, var(--iw-surface-strong) 90%, transparent);
      }

      .public-shell__cta {
        background: linear-gradient(135deg, var(--iw-brand) 0%, #8cb9ff 100%);
        color: white;
        box-shadow: 0 14px 30px rgba(76, 127, 214, 0.24);
      }

      .public-shell__cta:hover,
      .public-shell__ghost:hover {
        transform: translateY(-1px);
      }

      .public-shell__main {
        padding: 1.5rem clamp(1rem, 3vw, 2rem) 3rem;
      }

      @media (max-width: 980px) {
        .public-shell__header {
          grid-template-columns: 1fr;
          margin-top: 0.75rem;
        }

        .public-shell__nav,
        .public-shell__actions {
          justify-content: flex-start;
        }
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PublicShellComponent {
  private readonly authSession = inject(AuthSessionService);
  protected readonly isAuthenticated = computed(() => this.authSession.isAuthenticated());
  protected readonly canWrite = computed(() => {
    const role = this.authSession.role();

    return role === 'AUTHOR' || role === 'ADMIN';
  });
}
