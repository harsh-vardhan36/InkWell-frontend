import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { ThemeToggleComponent } from '../../../shared/components/theme-toggle/theme-toggle.component';
import { AuthSessionService } from '../../../features/auth/data-access/auth-session.service';

@Component({
  selector: 'app-dashboard-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, ThemeToggleComponent],
  template: `
    <div class="dashboard-shell">
      <aside class="dashboard-shell__sidebar">
        <a class="dashboard-shell__brand" routerLink="/feed">
          <span class="dashboard-shell__mark">IW</span>
          <div>
            <strong>InkWell Studio</strong>
            <p>Write, measure, grow.</p>
          </div>
        </a>

        <nav class="dashboard-shell__nav" aria-label="Workspace">
          <a routerLink="/feed" routerLinkActive="is-active" [routerLinkActiveOptions]="{ exact: true }">
            Feed
          </a>
          <a routerLink="/write" routerLinkActive="is-active">Write</a>
          <a routerLink="/dashboard" routerLinkActive="is-active">Dashboard</a>
          <a routerLink="/profile" routerLinkActive="is-active">Profile</a>
          <a routerLink="/pricing" routerLinkActive="is-active">Pricing</a>
        </nav>

        <div class="dashboard-shell__footer">
          <app-theme-toggle />
          <button type="button" class="dashboard-shell__signout" (click)="signOut()">
            Sign out
          </button>
        </div>
      </aside>

      <div class="dashboard-shell__content">
        <header class="dashboard-shell__topbar">
          <p>{{ welcomeCopy() }}</p>
          <a routerLink="/" class="dashboard-shell__home-link">View public home</a>
        </header>

        <main>
          <router-outlet />
        </main>
      </div>
    </div>
  `,
  styles: [
    `
      .dashboard-shell {
        min-height: 100vh;
        display: grid;
        grid-template-columns: minmax(240px, 280px) 1fr;
      }

      .dashboard-shell__sidebar {
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        gap: 1.5rem;
        padding: 1.5rem;
        margin: 1rem 0 1rem 1rem;
        border: 1px solid var(--iw-border);
        border-radius: 1.6rem;
        background: color-mix(in srgb, var(--iw-surface) 90%, transparent);
        box-shadow: var(--iw-glass-shadow);
        backdrop-filter: blur(24px) saturate(150%);
      }

      .dashboard-shell__brand {
        display: flex;
        gap: 0.9rem;
        text-decoration: none;
        align-items: center;
      }

      .dashboard-shell__mark {
        width: 2.8rem;
        height: 2.8rem;
        display: grid;
        place-items: center;
        border-radius: 1rem;
        background: linear-gradient(135deg, #7facff 0%, #d7e8ff 100%);
        color: #15356a;
        font-weight: 800;
      }

      .dashboard-shell__brand p {
        margin: 0.2rem 0 0;
        color: var(--iw-muted);
      }

      .dashboard-shell__nav {
        display: grid;
        gap: 0.45rem;
      }

      .dashboard-shell__nav a,
      .dashboard-shell__signout,
      .dashboard-shell__home-link {
        border-radius: 1rem;
        padding: 0.85rem 1rem;
        text-decoration: none;
        border: 1px solid transparent;
        transition:
          background-color 180ms ease,
          transform 180ms ease,
          border-color 180ms ease;
      }

      .dashboard-shell__nav a:hover,
      .dashboard-shell__nav a.is-active,
      .dashboard-shell__home-link:hover {
        background: color-mix(in srgb, var(--iw-surface-solid) 72%, transparent);
        border-color: var(--iw-border);
      }

      .dashboard-shell__nav a.is-active {
        color: var(--iw-brand);
      }

      .dashboard-shell__footer {
        display: grid;
        gap: 0.9rem;
      }

      .dashboard-shell__signout {
        border: 1px solid var(--iw-border);
        background: transparent;
        cursor: pointer;
        text-align: left;
      }

      .dashboard-shell__signout:hover {
        transform: translateY(-1px);
      }

      .dashboard-shell__content {
        padding: 1rem 1rem 1.5rem;
      }

      .dashboard-shell__topbar {
        display: flex;
        justify-content: space-between;
        gap: 1rem;
        align-items: center;
        margin: 0 0 1.5rem;
        padding: 1rem 1.2rem;
        border: 1px solid var(--iw-border);
        border-radius: 1.35rem;
        background: color-mix(in srgb, var(--iw-surface) 90%, transparent);
        box-shadow: var(--iw-glass-shadow);
        backdrop-filter: blur(18px) saturate(150%);
      }

      .dashboard-shell__topbar p {
        margin: 0;
        color: var(--iw-muted);
      }

      .dashboard-shell__home-link {
        background: color-mix(in srgb, var(--iw-surface-solid) 74%, transparent);
      }

      @media (max-width: 900px) {
        .dashboard-shell {
          grid-template-columns: 1fr;
        }

        .dashboard-shell__sidebar {
          margin-right: 1rem;
        }

        .dashboard-shell__topbar {
          flex-direction: column;
          align-items: flex-start;
        }
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DashboardShellComponent {
  private readonly authSession = inject(AuthSessionService);
  private readonly router = inject(Router);

  protected readonly welcomeCopy = computed(() =>
    this.authSession.isAuthenticated()
      ? 'Your workspace is ready. Draft, publish, and track what resonates.'
      : 'Sign in to unlock your creator workspace.',
  );

  protected signOut() {
    this.authSession.clearToken();
    void this.router.navigateByUrl('/login');
  }
}
