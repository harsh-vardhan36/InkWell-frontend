import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-pricing-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section class="pricing-hero">
      <p class="pricing-hero__eyebrow">Pricing</p>
      <h1>Choose the plan that matches how you create.</h1>
      <p>
        Start free for writing, code blocks, and basic analytics. Upgrade to Pro for
        image uploads, deeper reporting, and premium creator tools.
      </p>
    </section>

    <section class="pricing-grid">
      <article *ngFor="let plan of plans" class="pricing-card" [class.is-featured]="plan.featured">
        <p class="pricing-card__eyebrow">{{ plan.name }}</p>
        <h2>{{ plan.price }}</h2>
        <p class="pricing-card__copy">{{ plan.copy }}</p>
        <ul>
          <li *ngFor="let item of plan.features">{{ item }}</li>
        </ul>
        <a [routerLink]="plan.ctaLink">{{ plan.ctaLabel }}</a>
      </article>
    </section>
  `,
  styles: [
    `
      :host {
        display: grid;
        gap: 1.5rem;
      }

      .pricing-hero,
      .pricing-card {
        padding: clamp(1.4rem, 2vw, 2rem);
        border-radius: 1.7rem;
        background: var(--iw-surface);
        border: 1px solid var(--iw-border);
        box-shadow: var(--iw-shadow);
      }

      .pricing-hero__eyebrow,
      .pricing-card__eyebrow {
        margin: 0 0 0.7rem;
        color: var(--iw-brand);
        text-transform: uppercase;
        letter-spacing: 0.12em;
        font-size: 0.78rem;
        font-weight: 700;
      }

      .pricing-hero h1,
      .pricing-card h2 {
        margin: 0 0 0.8rem;
      }

      .pricing-hero p,
      .pricing-card__copy,
      .pricing-card li {
        color: var(--iw-muted);
        line-height: 1.7;
      }

      .pricing-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 1rem;
      }

      .pricing-card {
        display: grid;
        gap: 1rem;
      }

      .pricing-card.is-featured {
        background:
          linear-gradient(160deg, color-mix(in srgb, var(--iw-brand) 12%, var(--iw-surface)) 0%, var(--iw-surface) 100%);
      }

      .pricing-card ul {
        margin: 0;
        padding-left: 1.2rem;
      }

      .pricing-card a {
        width: fit-content;
        padding: 0.85rem 1.1rem;
        border-radius: 999px;
        background: var(--iw-brand-strong);
        color: var(--iw-surface);
        text-decoration: none;
      }

      @media (max-width: 800px) {
        .pricing-grid {
          grid-template-columns: 1fr;
        }
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PricingPageComponent {
  protected readonly plans = [
    {
      name: 'Free',
      price: '$0',
      copy: 'For readers and everyday writers getting started on InkWell.',
      features: [
        'Publish blogs with markdown and code blocks',
        'Like, comment, and subscribe to newsletters',
        'Basic analytics such as total views and peak time',
      ],
      ctaLabel: 'Create free account',
      ctaLink: '/register',
      featured: false,
    },
    {
      name: 'Pro',
      price: '$12 / month',
      copy: 'For creators who want richer storytelling and stronger audience insight.',
      features: [
        'Upload media into blog posts',
        'Access advanced analytics and top-performing post trends',
        'Unlock premium feature flags and custom profile upgrades',
      ],
      ctaLabel: 'Upgrade to Pro',
      ctaLink: '/dashboard',
      featured: true,
    },
  ];
}
