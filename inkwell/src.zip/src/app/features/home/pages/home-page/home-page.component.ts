import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section class="hero">
      <div class="hero__copy">
        <p class="hero__eyebrow">Editorial blogging for creators and curious readers</p>
        <h1>Read freely, write boldly, and grow your audience with InkWell.</h1>
        <p class="hero__text">
          Guests can explore stories, registered users can publish and engage, and Pro
          creators unlock analytics and media-rich storytelling.
        </p>

        <div class="hero__actions">
          <a routerLink="/register" class="hero__primary">Start writing</a>
          <a routerLink="/pricing" class="hero__secondary">Compare Free vs Pro</a>
        </div>

        <div class="hero__metrics">
          <article>
            <strong>24k+</strong>
            <span>weekly readers</span>
          </article>
          <article>
            <strong>1.9k</strong>
            <span>creator newsletters</span>
          </article>
          <article>
            <strong>Clean UI</strong>
            <span>built for long-form reading</span>
          </article>
        </div>
      </div>

      <div class="hero__panel">
        <article *ngFor="let item of spotlight" class="hero__card">
          <span>{{ item.kicker }}</span>
          <h2>{{ item.title }}</h2>
          <p>{{ item.copy }}</p>
        </article>
      </div>
    </section>

    <section class="section">
      <div class="section__header">
        <div>
          <p class="section__eyebrow">Latest and trending</p>
          <h2>Start with what the community is reading now.</h2>
        </div>
        <a routerLink="/feed">Open personalized feed</a>
      </div>

      <div class="story-grid">
        <article *ngFor="let post of featuredPosts" class="story-card">
          <div class="story-card__meta">
            <span>{{ post.category }}</span>
            <span>{{ post.readTime }}</span>
          </div>
          <h3>
            <a [routerLink]="['/blog', post.id]">{{ post.title }}</a>
          </h3>
          <p>{{ post.excerpt }}</p>
          <footer>
            <strong>{{ post.author }}</strong>
            <span>{{ post.metric }}</span>
          </footer>
        </article>
      </div>
    </section>

    <section class="section section--split">
      <div class="section__surface">
        <p class="section__eyebrow">Why creators choose InkWell</p>
        <ul class="bullet-list">
          <li>Markdown and rich-text friendly publishing flow</li>
          <li>Code blocks, comments, likes, and newsletter capture</li>
          <li>Day/night reading mode for long-form sessions</li>
          <li>Upgrade path for analytics and media uploads</li>
        </ul>
      </div>

      <div class="section__surface">
        <p class="section__eyebrow">Categories</p>
        <div class="chip-list">
          <span *ngFor="let tag of tags">{{ tag }}</span>
        </div>
      </div>
    </section>
  `,
  styles: [
    `
      :host {
        display: grid;
        gap: 2rem;
      }

      .hero,
      .section--split {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 1.5rem;
      }

      .hero {
        padding: clamp(1rem, 2vw, 1.5rem) 0 1rem;
      }

      .hero__copy,
      .hero__panel,
      .section__surface {
        padding: clamp(1.3rem, 3vw, 2.3rem);
        border-radius: 1.75rem;
        background: color-mix(in srgb, var(--iw-surface) 94%, transparent);
        border: 1px solid var(--iw-border);
        box-shadow: var(--iw-glass-shadow);
        backdrop-filter: blur(24px) saturate(150%);
      }

      .hero__eyebrow,
      .section__eyebrow,
      .hero__card span,
      .story-card__meta {
        margin: 0 0 0.9rem;
        color: var(--iw-brand);
        text-transform: uppercase;
        letter-spacing: 0.12em;
        font-size: 0.78rem;
        font-weight: 700;
      }

      h1 {
        margin: 0;
        font-size: clamp(2.8rem, 6vw, 5.2rem);
        line-height: 0.95;
        max-width: 11ch;
      }

      .hero__text,
      .hero__card p,
      .story-card p,
      .bullet-list {
        color: var(--iw-muted);
        line-height: 1.7;
      }

      .hero__actions {
        display: flex;
        gap: 0.8rem;
        flex-wrap: wrap;
        margin-top: 1.5rem;
      }

      .hero__primary,
      .hero__secondary {
        padding: 0.9rem 1.2rem;
        border-radius: 999px;
        text-decoration: none;
      }

      .hero__primary {
        background: linear-gradient(135deg, var(--iw-brand) 0%, #83b1ff 100%);
        color: white;
        box-shadow: 0 16px 36px rgba(70, 123, 217, 0.24);
      }

      .hero__secondary {
        border: 1px solid var(--iw-border);
        background: color-mix(in srgb, var(--iw-surface-solid) 72%, transparent);
      }

      .hero__panel {
        display: grid;
        gap: 1rem;
        background:
          linear-gradient(145deg, rgba(255, 255, 255, 0.78) 0%, rgba(229, 239, 255, 0.68) 100%);
      }

      .hero__card {
        padding: 1.1rem;
        border-radius: 1.2rem;
        background: color-mix(in srgb, var(--iw-surface-solid) 64%, transparent);
        border: 1px solid var(--iw-border);
        backdrop-filter: blur(16px);
      }

      .hero__card h2,
      .section h2 {
        margin: 0 0 0.65rem;
      }

      .section {
        display: grid;
        gap: 1rem;
      }

      .hero__metrics {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 0.9rem;
        margin-top: 1.75rem;
      }

      .hero__metrics article {
        padding: 1rem;
        border-radius: 1.15rem;
        background: color-mix(in srgb, var(--iw-surface-solid) 60%, transparent);
        border: 1px solid var(--iw-border);
      }

      .hero__metrics strong,
      .hero__metrics span {
        display: block;
      }

      .hero__metrics strong {
        font-size: 1.1rem;
        font-family: 'Inter', 'Segoe UI', sans-serif;
        color: var(--iw-ink);
      }

      .hero__metrics span {
        margin-top: 0.35rem;
        color: var(--iw-muted);
      }

      .section__header {
        display: flex;
        justify-content: space-between;
        gap: 1rem;
        align-items: end;
      }

      .story-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 1rem;
      }

      .story-card {
        padding: 1.3rem;
        border-radius: 1.4rem;
        background: color-mix(in srgb, var(--iw-surface) 94%, transparent);
        border: 1px solid var(--iw-border);
        box-shadow: var(--iw-glass-shadow);
        backdrop-filter: blur(18px) saturate(150%);
      }

      .story-card__meta {
        display: flex;
        justify-content: space-between;
      }

      .story-card h3 {
        margin: 0 0 0.75rem;
        font-size: 1.35rem;
      }

      .story-card footer {
        display: flex;
        justify-content: space-between;
        gap: 1rem;
        color: var(--iw-muted);
      }

      .bullet-list {
        margin: 0;
        padding-left: 1.2rem;
      }

      .chip-list {
        display: flex;
        gap: 0.7rem;
        flex-wrap: wrap;
      }

      .chip-list span {
        padding: 0.7rem 1rem;
        border-radius: 999px;
        background: var(--iw-chip);
        color: var(--iw-brand);
      }

      @media (max-width: 960px) {
        .hero,
        .section--split,
        .story-grid {
          grid-template-columns: 1fr;
        }

        .hero__metrics {
          grid-template-columns: 1fr;
        }

        .section__header {
          align-items: start;
          flex-direction: column;
        }
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HomePageComponent {
  protected readonly spotlight = [
    {
      kicker: 'Guest reading',
      title: 'Browse latest and trending stories before you sign in.',
      copy: 'The public home is optimized for discovery, SEO, and clear prompts to join the community.',
    },
    {
      kicker: 'Creator tools',
      title: 'Draft, edit, autosave, and publish with confidence.',
      copy: 'A focused writing flow supports markdown, code blocks, and upgrade-aware media tools.',
    },
    {
      kicker: 'Growth',
      title: 'Turn readers into subscribers with newsletters and analytics.',
      copy: 'Pro creators get deeper insights into what works, when audiences arrive, and which posts perform best.',
    },
  ];

  protected readonly featuredPosts = [
    {
      id: 'scaling-editorial-systems',
      category: 'Trending',
      readTime: '6 min read',
      title: 'How small creator teams can scale editorial systems without losing voice',
      excerpt: 'A practical framework for balancing publishing cadence, quality standards, and audience trust.',
      author: 'Mira Chen',
      metric: '1.8k reads',
    },
    {
      id: 'writing-for-devs',
      category: 'Latest',
      readTime: '8 min read',
      title: 'Writing technical blogs that teach instead of overwhelm',
      excerpt: 'Structure, narrative pacing, and examples that help readers feel capable instead of buried.',
      author: 'Arjun Mehta',
      metric: '324 likes',
    },
    {
      id: 'newsletter-loops',
      category: 'Editors pick',
      readTime: '5 min read',
      title: 'Newsletter loops that make every article more valuable over time',
      excerpt: 'A lightweight loop between posts, subscriptions, and follow-up emails that compounds audience growth.',
      author: 'Nadia Brooks',
      metric: '92 comments',
    },
  ];

  protected readonly tags = ['Engineering', 'Design', 'Startups', 'Writing', 'AI', 'Career', 'Culture'];
}
