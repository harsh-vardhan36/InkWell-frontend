import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'app-dashboard-page',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section class="dashboard-grid">
      <article *ngFor="let card of summaryCards" class="dashboard-card">
        <p class="dashboard-card__eyebrow">{{ card.label }}</p>
        <h1>{{ card.value }}</h1>
        <p>{{ card.copy }}</p>
      </article>
    </section>

    <section class="dashboard-grid dashboard-grid--detail">
      <article class="dashboard-card dashboard-card--wide">
        <p class="dashboard-card__eyebrow">Views over time</p>
        <div class="chart">
          <div *ngFor="let point of chartPoints" class="chart__bar" [style.height.%]="point.height">
            <span>{{ point.label }}</span>
          </div>
        </div>
      </article>

      <article class="dashboard-card">
        <p class="dashboard-card__eyebrow">Top-performing blogs</p>
        <div *ngFor="let item of topPosts" class="dashboard-row">
          <strong>{{ item.title }}</strong>
          <span>{{ item.metric }}</span>
        </div>
      </article>
    </section>
  `,
  styles: [
    `
      .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 1rem;
      }

      .dashboard-grid--detail {
        margin-top: 1rem;
        grid-template-columns: minmax(0, 2fr) minmax(280px, 1fr);
      }

      .dashboard-card {
        padding: 1.4rem;
        border-radius: 1.5rem;
        background: var(--iw-surface);
        border: 1px solid var(--iw-border);
        box-shadow: var(--iw-shadow);
      }

      .dashboard-card__eyebrow {
        margin: 0 0 0.7rem;
        color: var(--iw-brand);
        text-transform: uppercase;
        letter-spacing: 0.12em;
        font-size: 0.78rem;
        font-weight: 700;
      }

      .dashboard-card h1,
      .dashboard-card p {
        margin: 0;
      }

      .dashboard-card p,
      .dashboard-row span {
        color: var(--iw-muted);
        line-height: 1.7;
      }

      .chart {
        height: 260px;
        display: grid;
        grid-template-columns: repeat(7, minmax(0, 1fr));
        gap: 0.8rem;
        align-items: end;
      }

      .chart__bar {
        min-height: 4rem;
        border-radius: 1rem 1rem 0.6rem 0.6rem;
        background: linear-gradient(180deg, var(--iw-brand) 0%, #f0b25f 100%);
        display: flex;
        align-items: end;
        justify-content: center;
        padding: 0.7rem 0.3rem;
      }

      .chart__bar span {
        color: #18120e;
        font-size: 0.75rem;
        font-weight: 700;
      }

      .dashboard-row {
        display: flex;
        justify-content: space-between;
        gap: 1rem;
        padding: 0.95rem 0;
        border-top: 1px solid var(--iw-border);
      }

      .dashboard-row:first-of-type {
        border-top: 0;
        padding-top: 0;
      }

      @media (max-width: 960px) {
        .dashboard-grid,
        .dashboard-grid--detail {
          grid-template-columns: 1fr;
        }
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DashboardPageComponent {
  protected readonly summaryCards = [
    { label: 'Total views', value: '18.4k', copy: 'Your free-plan summary remains visible at a glance.' },
    { label: 'Peak time', value: '8:00 PM', copy: 'Readers are most active during the evening publish window.' },
    { label: 'Engagement rate', value: '7.8%', copy: 'Pro analytics can expand this into comments, saves, and shares.' },
  ];

  protected readonly chartPoints = [
    { label: 'Mon', height: 32 },
    { label: 'Tue', height: 44 },
    { label: 'Wed', height: 53 },
    { label: 'Thu', height: 71 },
    { label: 'Fri', height: 64 },
    { label: 'Sat', height: 81 },
    { label: 'Sun', height: 58 },
  ];

  protected readonly topPosts = [
    { title: 'Better writing systems for dev teams', metric: '4.7k views' },
    { title: 'The anatomy of a great technical article', metric: '3.3k views' },
    { title: 'Shipping docs that people can actually use', metric: '2.1k views' },
  ];
}
