import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';

@Component({
  selector: 'app-post-detail-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <article class="post-detail">
      <header class="post-detail__hero">
        <p class="post-detail__eyebrow">Blog detail</p>
        <h1>{{ article().title }}</h1>
        <p class="post-detail__summary">{{ article().summary }}</p>
        <div class="post-detail__meta">
          <span>{{ article().author }}</span>
          <span>{{ article().published }}</span>
          <span>{{ article().readTime }}</span>
        </div>
      </header>

      <section class="post-detail__content">
        <div class="post-detail__body">
          <p *ngFor="let paragraph of article().body">{{ paragraph }}</p>

          <div class="post-detail__actions">
            <button type="button">Like post</button>
            <button type="button">Comment</button>
            <button type="button">Subscribe</button>
          </div>
        </div>

        <aside class="post-detail__sidebar">
          <section class="panel">
            <p class="post-detail__eyebrow">Author</p>
            <h2>{{ article().author }}</h2>
            <p>{{ article().authorBio }}</p>
          </section>

          <section class="panel">
            <p class="post-detail__eyebrow">Related blogs</p>
            <a *ngFor="let related of relatedPosts" [routerLink]="['/blog', related.id]">
              {{ related.title }}
            </a>
          </section>
        </aside>
      </section>
    </article>
  `,
  styles: [
    `
      .post-detail {
        display: grid;
        gap: 1.5rem;
      }

      .post-detail__hero,
      .post-detail__body,
      .panel {
        padding: clamp(1.3rem, 2vw, 2rem);
        border-radius: 1.6rem;
        background: var(--iw-surface);
        border: 1px solid var(--iw-border);
        box-shadow: var(--iw-shadow);
      }

      .post-detail__eyebrow {
        margin: 0 0 0.8rem;
        color: var(--iw-brand);
        text-transform: uppercase;
        letter-spacing: 0.12em;
        font-size: 0.78rem;
        font-weight: 700;
      }

      .post-detail h1 {
        margin: 0;
        font-size: clamp(2.5rem, 5vw, 4.4rem);
      }

      .post-detail__summary,
      .post-detail__body p,
      .panel p,
      .panel a {
        color: var(--iw-muted);
        line-height: 1.8;
      }

      .post-detail__meta,
      .post-detail__actions,
      .post-detail__content {
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
      }

      .post-detail__content {
        display: grid;
        grid-template-columns: minmax(0, 2fr) minmax(280px, 0.9fr);
        align-items: start;
      }

      .post-detail__actions button {
        border: 1px solid var(--iw-border);
        border-radius: 999px;
        padding: 0.85rem 1rem;
        background: transparent;
        cursor: pointer;
      }

      .post-detail__sidebar {
        display: grid;
        gap: 1rem;
      }

      .panel a {
        display: block;
        margin-top: 0.9rem;
      }

      @media (max-width: 960px) {
        .post-detail__content {
          grid-template-columns: 1fr;
        }
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PostDetailPageComponent {
  private readonly route = inject(ActivatedRoute);

  protected readonly article = computed(() => {
    const id = this.route.snapshot.paramMap.get('id') ?? 'story';

    return {
      title: `Inside ${id.replace(/-/g, ' ')}: an InkWell story template`,
      summary:
        'This detail page is ready for markdown or rich-text content, author context, comments, likes, and related article modules.',
      author: 'InkWell Editorial',
      published: 'April 20, 2026',
      readTime: '6 min read',
      authorBio:
        'InkWell Editorial curates product thinking, creator tools, and systems for better publishing.',
      body: [
        'InkWell separates public reading from authenticated interaction so guests can discover content while registered users unlock participation. That balance keeps the product accessible without weakening the value of signing in.',
        'On the frontend, the detail page should support sanitized rich content, a clear author module, related posts, and interaction prompts that adapt based on session state.',
        'This starter implementation focuses on the shell and information hierarchy so the backend APIs for likes, comments, and related posts can plug in later without redesigning the page.',
      ],
    };
  });

  protected readonly relatedPosts = [
    { id: 'better-comment-experiences', title: 'Designing comment experiences that stay readable' },
    { id: 'analytics-for-creators', title: 'What creator analytics should actually show' },
    { id: 'publishing-with-rhythm', title: 'How publishing rhythm shapes reader trust' },
  ];
}
