import { CommonModule } from '@angular/common';
import { Component, computed, inject, signal } from '@angular/core';
import { AbstractControl, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize, switchMap } from 'rxjs';
import { SocialLoginButtonsComponent } from '../../components/social-login-buttons/social-login-buttons.component';
import { AuthApiService } from '../../data-access/auth-api.service';
import { AuthSessionService } from '../../data-access/auth-session.service';

const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!]).*$/;

function passwordsMatch(control: AbstractControl) {
  const password = control.get('password')?.value;
  const confirmPassword = control.get('confirmPassword')?.value;

  return password === confirmPassword ? null : { passwordMismatch: true };
}

@Component({
  selector: 'app-register-page',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, SocialLoginButtonsComponent],
  templateUrl: './register-page.component.html',
  styleUrl: './register-page.component.scss',
})
export class RegisterPageComponent {
  private readonly fb = inject(FormBuilder);
  private readonly router = inject(Router);
  private readonly authApi = inject(AuthApiService);
  private readonly authSession = inject(AuthSessionService);

  readonly showPassword = signal(false);
  readonly showConfirmPassword = signal(false);
  readonly isSubmitting = signal(false);
  readonly submitError = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group(
    {
      username: ['', [Validators.required]],
      fullName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: [
        '',
        [Validators.required, Validators.minLength(8), Validators.pattern(passwordPattern)],
      ],
      confirmPassword: ['', [Validators.required]],
      agreeToTerms: [false, [Validators.requiredTrue]],
    },
    { validators: passwordsMatch },
  );

  readonly passwordsDoNotMatch = computed(
    () =>
      this.form.touched &&
      this.form.hasError('passwordMismatch') &&
      this.form.controls.confirmPassword.touched,
  );

  togglePassword() {
    this.showPassword.update((value) => !value);
  }

  toggleConfirmPassword() {
    this.showConfirmPassword.update((value) => !value);
  }

  onSubmit() {
    this.submitError.set(null);

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const { username, fullName, email, password } = this.form.getRawValue();

    this.isSubmitting.set(true);
    this.authApi
      .register({ username, fullName, email, password })
      .pipe(
        switchMap((response) => {
          const token = this.authApi.extractToken(response);

          if (!token) {
            throw new Error('Account created, but no token was returned by the server.');
          }

          this.authSession.saveToken(token);

          return this.authApi.getProfile();
        }),
        finalize(() => this.isSubmitting.set(false)),
      )
      .subscribe({
        next: (user) => {
          this.authSession.saveUser(user);
          void this.router.navigateByUrl(this.authSession.getPostLoginRedirectUrl());
        },
        error: (error) => {
          const message =
            error?.integrationHint ??
            (error instanceof Error ? error.message : null) ??
            (typeof error?.error === 'string' ? error.error : null) ??
            error?.error?.message ??
            error?.error?.error ??
            error?.error?.details ??
            (error?.status === 409
              ? 'Email already registered.'
              : 'Unable to create your account right now. Please try again.');

          this.submitError.set(message);
        },
      });
  }

  onOauth(provider: 'google' | 'github') {
    if (typeof window !== 'undefined') {
      window.location.href = this.authApi.getOauthUrl(provider);
    }
  }
}
