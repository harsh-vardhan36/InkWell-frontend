import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthApiService } from '../../data-access/auth-api.service';
import { AuthSessionService } from '../../data-access/auth-session.service';

@Component({
  selector: 'app-oauth-redirect',
  standalone: true,
  template: `
    <div style="text-align: center; margin-top: 50px;">
      <h2>Logging you in...</h2>
      <p>Please wait while we sync your account.</p>
    </div>
  `,
})
export class OauthRedirectComponent implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly authApi = inject(AuthApiService);           // ← add
  private readonly authSession = inject(AuthSessionService);   // ← add

  ngOnInit(): void {
    const token = this.route.snapshot.queryParamMap.get('token');

    if (!token) {
      void this.router.navigate(['/login']);
      return;
    }

    // ✅ Save token first so getProfile() can attach it to the request
    this.authSession.saveToken(token);

    // ✅ Now fetch the user profile exactly like login-page does
    this.authApi.getProfile().subscribe({
      next: (user) => {
        this.authSession.saveUser(user);                              // ← saves name, email, role
        void this.router.navigateByUrl(this.authSession.getPostLoginRedirectUrl());
      },
      error: () => {
        // Profile fetch failed — still let them in, just without user data
        void this.router.navigateByUrl(this.authSession.getPostLoginRedirectUrl());
      },
    });
  }
}