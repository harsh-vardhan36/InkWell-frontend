import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-social-login-buttons',
  standalone: true,
  templateUrl: './social-login-buttons.component.html',
  styleUrl: './social-login-buttons.component.scss',
})
export class SocialLoginButtonsComponent {
  @Output() oauthSelected = new EventEmitter<'google' | 'github'>();

  onSelect(provider: 'google' | 'github') {
    const oauthUrl = `http://localhost:8080/oauth2/authorization/${provider}`;
    window.location.href = oauthUrl; // Redirect to the correct OAuth2 URL
  }
}