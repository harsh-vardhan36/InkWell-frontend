import { CommonModule } from '@angular/common';
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-feed-page',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section class="feed">
      <div class="feed__main">
        <header class="feed__header">
          <div>
            <p class="feed__eyebrow">Personalized feed</p>
            <h1>Stories tuned to your interests and writing goals.</h1>
          </div>
          <a routerLink="/write" class="feed__cta">Write blog</a>
        </header>

        <article *ngFor="let post of posts" class="feed-card">
          <div class="feed-card__meta">
            <span>{{ post.category }}</span>
            <span>{{ post.readTime }}</span>
          </div>
          <h2><a [routerLink]="['/blog', post.id]">{{ post.title }}</a></h2>
          <p>{{ post.excerpt }}</p>
          <footer class="feed-card__footer">
            <div>
              <strong>{{ post.author }}</strong>
              <span>{{ post.published }}</span>
            </div>
            <div>{{ post.engagement }}</div>
          </footer>
        </article>
      </div>

      <aside class="feed__sidebar">
        <section class="feed__panel">
          <p class="feed__eyebrow">Suggested creators</p>
          <div *ngFor="let creator of creators" class="mini-row">
            <div>
              <strong>{{ creator.name }}</strong>
              <p>{{ creator.topic }}</p>
            </div>
            <button type="button">Follow</button>
          </div>
        </section>

        <section class="feed__panel">
          <p class="feed__eyebrow">Trending tags</p>
          <div class="chips">
            <span *ngFor="let tag of tags">{{ tag }}</span>
          </div>
        </section>
      </aside>
    </section>
  `,
  styles: [
    `
      .feed {
        display: grid;
        grid-template-columns: minmax(0, 2fr) minmax(280px, 0.95fr);
        gap: 1.5rem;
      }

      .feed__header,
      .feed-card,
      .feed__panel {
        padding: 1.4rem;
        border-radius: 1.5rem;
        background: color-mix(in srgb, var(--iw-surface) 94%, transparent);
        border: 1px solid var(--iw-border);
        box-shadow: var(--iw-glass-shadow);
        backdrop-filter: blur(20px) saturate(145%);
      }

      .feed__main {
        display: grid;
        gap: 1rem;
      }

      .feed__header {
        display: flex;
        justify-content: space-between;
        gap: 1rem;
        align-items: end;
      }

      .feed__eyebrow,
      .feed-card__meta {
        margin: 0 0 0.7rem;
        color: var(--iw-brand);
        text-transform: uppercase;
        letter-spacing: 0.12em;
        font-size: 0.78rem;
        font-weight: 700;
      }

      .feed__cta,
      .mini-row button {
        border: 0;
        border-radius: 999px;
        padding: 0.85rem 1.1rem;
        background: linear-gradient(135deg, var(--iw-brand) 0%, #82aeff 100%);
        color: white;
        text-decoration: none;
        cursor: pointer;
        box-shadow: 0 14px 30px rgba(76, 127, 214, 0.22);
      }

      .feed-card__meta,
      .feed-card__footer,
      .mini-row {
        display: flex;
        justify-content: space-between;
        gap: 1rem;
      }

      .feed-card h2 {
        margin: 0 0 0.75rem;
        font-size: 1.7rem;
        line-height: 1.1;
      }

      .feed-card p,
      .mini-row p {
        margin: 0;
        color: var(--iw-muted);
        line-height: 1.65;
      }

      .feed__sidebar {
        display: grid;
        gap: 1rem;
        align-self: start;
      }

      .mini-row {
        align-items: center;
        padding: 0.8rem 0;
        border-top: 1px solid var(--iw-border);
      }

      .mini-row:first-of-type {
        border-top: 0;
        padding-top: 0;
      }

      .chips {
        display: flex;
        gap: 0.65rem;
        flex-wrap: wrap;
      }

      .chips span {
        padding: 0.65rem 0.95rem;
        border-radius: 999px;
        background: var(--iw-chip);
        color: var(--iw-brand);
      }

      @media (max-width: 960px) {
        .feed {
          grid-template-columns: 1fr;
        }

        .feed__header {
          flex-direction: column;
          align-items: start;
        }
      }
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FeedPageComponent {
  protected readonly posts = [
    {
      id: 'future-of-blog-newsletters',
      category: 'For you',
      readTime: '7 min read',
      title: 'Why newsletters are becoming the second homepage for modern blogs',
      excerpt: 'A creator-first look at how email compounds reach long after a post leaves the front page.',
      author: 'Sofia Bennett',
      published: 'Published 2 hours ago',
      engagement: '481 likes',
    },
    {
      id: 'angular-editor-patterns',
      category: 'Because you read Engineering',
      readTime: '9 min read',
      title: 'Authoring flows in Angular: autosave, drafts, and resilient editors',
      excerpt: 'Patterns for managing draft state, save indicators, and rich content editing without heavy global state.',
      author: 'Rahul Verma',
      published: 'Published yesterday',
      engagement: '66 comments',
    },
    {
      id: 'creator-funnels',
      category: 'Recommended',
      readTime: '4 min read',
      title: 'The simplest funnel from blog reader to loyal subscriber',
      excerpt: 'A clean welcome series can start with one article, one inline form, and one consistent promise.',
      author: 'Ava Collins',
      published: 'Published 3 days ago',
      engagement: 'Top 3% this week',
    },
  ];

  protected readonly creators = [
    { name: 'Devika Shah', topic: 'Writes on product-led growth and analytics' },
    { name: 'Owen Clark', topic: 'Breaks down frontend systems and performance' },
    { name: 'Noah Kim', topic: 'Shares workflows for newsletters and community loops' },
  ];

  protected readonly tags = ['Angular', 'Newsletters', 'SEO', 'Performance', 'Writing Systems'];
}
